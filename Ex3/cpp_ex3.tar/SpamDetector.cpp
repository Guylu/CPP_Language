#include <iostream>
#include "HashMap.hpp"
#include "string"
#include <fstream>
#include <algorithm>

using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::ifstream;

static const char COMMA = ',';
static const int NUMOFARGS = 4;
static const int THRESHOLD = 3;
static const int DATA = 1;
static const int MSG = 2;

/**
 * will check num of occurrences of string pat in string str
 * took inspiration from https://www.geeksforgeeks.org/frequency-substring-string/
 * @param pat pattern to look
 * @param str string to look in
 * @return num of occurrences
 */
int countFreq(const string &pat, const string &str)
{
    size_t patLen = pat.length();
    size_t strLen = str.length();
    if (patLen > strLen)
    {
        return 0;
    }
    size_t i = 0;
    size_t j = 0;
    size_t res = 0;
    for (i = 0; i < (strLen - patLen) + 1; ++i)
    {
        for (j = 0; j < patLen; ++j)
        {
            if (str[i + j] != pat[j])
            {
                break;
            }
        }
        if (j == patLen)
        {
            // got a match!
            res++;
        }
    }
    return res;
}

/**
 * will check the line of text for validity and initialize the phrase and score
 * @param line the line in the database
 * @param score score to initialize
 * @param phrase phrase to initialize
 */
void validateLine(string line, int &score, string &phrase)
{
    size_t comma = 0;
    for (size_t i = 0; i < line.size(); ++i)
    {
        if (line[i] == COMMA)
        {
            if (comma != 0)
            {
                //more than one comma
                throw invalidException();
            }
            comma = i;
        }
    }
    // check position of comma is valid - the -1 refers to the last char of the line
    if (comma == 0 || comma == line.size() - 1)
    {
        throw invalidException();
    }
    string num;
    for (size_t i = comma + 1; i < line.size(); ++i)
    {
        num += line[i];
    }
    // check that all chars are digits
    if (!std::all_of(num.begin(), num.end(), ::isdigit))
    {
        throw invalidException();
    }
    try
    {
        score = std::stoi(num);
        if (score < 0)
        {
            throw invalidException();
        }
    }
    catch (...)
    {
        throw invalidException();
    }
    for (size_t i = 0; i < comma; ++i)
    {
        phrase += line[i];
    }
    // turn to small case letters
    std::transform(phrase.begin(), phrase.end(), phrase.begin(), [](unsigned char c)
    { return std::tolower(c); });

}

/**
 * will parse the database to create a dictionary of bad phrases to their penalty
 * @param argc num of args
 * @param argv args
 * @param dict hashMap to create
 * @param message given message
 * @param threshold the threshold
 */
void parse(int argc, char *const *argv, HashMap<string, int> &dict, string &message, int &threshold)
{
    if (argc != NUMOFARGS)
    {
        throw usageException();
    }
    try
    {
        threshold = std::stoi(argv[THRESHOLD]);
        if (threshold <= 0)
        {
            throw invalidException();
        }
    }
    catch (...)
    {
        throw invalidException();
    }
    string line;
    int score;
    string phrase;
    ifstream myfile(argv[DATA]);
    if (myfile.is_open())
    {
        while (getline(myfile, line))
        {
            phrase = "";
            try
            {
                validateLine(line, score, phrase);
                dict[phrase] = score;
            }
            catch (const invalidException &e)
            {
                myfile.close();
                throw;
            }
        }
        myfile.close();
    }
    else
    {
        throw invalidException();
    }
    ifstream ifs(argv[MSG]);
    if (ifs.is_open())
    {
        //read all file as one big 'chunk'
        string temp((std::istreambuf_iterator<char>(ifs)), (std::istreambuf_iterator<char>()));
        // turn to small case letters
        std::transform(temp.begin(), temp.end(), temp.begin(), [](unsigned char c)
        { return std::tolower(c); });
        message = temp;
        myfile.close();
    }
    else
    {
        throw invalidException();
    }

}

/**
 * will calculate the score for the message
 * @param dict hashMap of bad word to their penalty
 * @param message message to inspect
 * @return score of message
 */
int calcScore(const HashMap<string, int> &dict, const string &message)
{
    int totalScore = 0;
    for (HashMap<string, int>::const_iterator iterator = dict.begin(); iterator != dict.end();
         ++iterator)
    {
        string s = iterator->first;
        totalScore += countFreq(s, message) * iterator->second;
    }
    return totalScore;
}

/**
 * will print if the message is spam or not
 * @param threshold given threshold
 * @param totalScore calculated score
 */
void result(int threshold, int totalScore)
{
    if (totalScore >= threshold)
    {
        cout << "SPAM" << endl;
    }
    else
    {
        cout << "NOT_SPAM" << endl;
    }
}

/**
 * main method to run the program
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char *argv[])
{
    //my args for input:
    HashMap<string, int> dict;
    string message;
    int threshold;
    //initialize all inputs:
    //create dict to hold "bad phrase" ====> score for single appearance
    // message to hold the massage ro inspect, and threshold to determine if it is SPAM
    try
    {
        parse(argc, argv, dict, message, threshold);
    }
    catch (const genException &e)
    {
        cerr << e.what() << endl;
        return EXIT_FAILURE;
    }
    //calculate score based on inputs
    int totalScore = calcScore(dict, message);
    // conclude whether it is indeed a SPAM message or not and print the result to the user
    result(threshold, totalScore);
    return EXIT_SUCCESS;
}
